1. Build the DynamicLibs Solution, there will be DLL files generated in DynamicLibs\x64\Debug.
2. Build and run Pool project.
When the operating system loads your app, it looks for the DLLs.
If it can't find the DLL in certain system directories, the environment path, or the local app directory, the load fails. You'll see an error message like this:
"The code execution cannot proceed because FishLib.dll was not found".

To avoid this, you should copy all the DLLs file in DynamicLibs\x64\Debug to Pool\Pool.
