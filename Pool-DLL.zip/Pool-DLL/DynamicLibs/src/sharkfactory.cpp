#include "sharkfactory.h"

SharkFactory::SharkFactory(std::vector<Position> legalPos)
{
  legalPos_ = legalPos;
}

Fish* SharkFactory::create ()
{
    int n=abs((int)random(legalPos_.size()-1));
    Position pos = legalPos_[n];
    return new Shark(pos.x,pos.y);
}
std::string SharkFactory::name()
{
    return "Shark";
}

extern "C" __declspec(dllexport) FishFactory * create_factory(std::vector<Position> legalPos)
{
    return new SharkFactory(legalPos);
}
