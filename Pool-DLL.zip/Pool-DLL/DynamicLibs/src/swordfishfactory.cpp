#include "swordfishfactory.h"

SwordFishFactory::SwordFishFactory(std::vector<Position> legalPos)
{
  legalPos_ = legalPos;
}

Fish* SwordFishFactory ::create ()
{
    int n=abs((int)random(legalPos_.size()-1));
    Position pos = legalPos_[n];
    return new SwordFish(pos.x,pos.y);
}

std::string SwordFishFactory::name()
{
    return "Sword Fish";
}

extern "C" __declspec(dllexport) FishFactory * create_factory(std::vector<Position> legalPos)
{
    return new SwordFishFactory(legalPos);
}