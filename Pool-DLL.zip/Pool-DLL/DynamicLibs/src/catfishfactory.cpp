#include "catfishfactory.h"

CatFishFactory::CatFishFactory(std::vector<Position> legalPos)
{
  legalPos_ = legalPos;
}
 
Fish* CatFishFactory ::create ()
{
    int n=abs((int)random(legalPos_.size()-1));
    Position pos = legalPos_[n];
    return new CatFish(pos.x,pos.y);
}

std::string CatFishFactory::name()
{
    return "Cat Fish";
}
 
extern "C" __declspec(dllexport) FishFactory * create_factory(std::vector<Position> legalPos)
{
    return new CatFishFactory(legalPos);
}
 