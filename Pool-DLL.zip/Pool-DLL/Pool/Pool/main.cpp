#include "fishfactory.h"
#include "pool.h"
#include <iostream>
#include <windows.h>
#include <vector>

using namespace std ;

static std::vector<FishFactory*> factories;
/* Setup
 - Create a pool with size w*h
 - Create a penjing with a vector of poles coordinate and add it to the Pool
 - Create fishes and put them to fishes list of the Pool
 - In each loop, every fish make move and the stronger one eat weak one if they meet each other
 - The game will be over when only a fish left*/

void loadFactories(std::vector<FishFactory*>& factories, const vector<Position> legalPos)
{
    std::vector<HMODULE> handles;
    WIN32_FIND_DATA find_data;
    HANDLE find_handle = FindFirstFile("../../DynamicLibs/x64/Debug/*.dll", &find_data);
    if (find_handle != INVALID_HANDLE_VALUE) {
        do {
            HMODULE handle = LoadLibrary(find_data.cFileName);
            if (handle) {
                typedef FishFactory* (*create_factory_t)(vector<Position>);
                create_factory_t create_factory = (create_factory_t)GetProcAddress(handle, "create_factory");
                if (create_factory) {
                    FishFactory* factory = create_factory(legalPos);
                    factories.push_back(factory);
                    handles.push_back(handle);
                }

                else {
                    FreeLibrary(handle);
                }
            }
        } while (FindNextFile(find_handle, &find_data));
    }
    FindClose(find_handle);
    cout << "Loaded " << factories.size() << " types of fishes." << endl;
    for (FishFactory* factory : factories) {
        cout << factory->name() << " , ";
    }
    cout << endl;

}

Pool setUp()
{
    int h=0;
    int w=0;
    cout << "Enter height and wide of the pool :" << endl;
    while (h<=0 ||w <=0)
        cin >> h>>w;
    Pool pool(h,w);
    vector<Position> p = {{2,0},{4,4},{7,0}};
    Obstacle pen(p,"Penjing");
    vector<Position> sw = {{0,5},{6,8},{8,3}};

    Obstacle seaWeed(sw,"SeaWeed");
    pool.setObstacle(pen);
    pool.setObstacle(seaWeed);
    loadFactories(factories, pool.getLegalPos());
    cout << "Please enter the number of each type you want to put into the pool." << endl;
    for (FishFactory* factory : factories) {
        cout << factory->name() << " : ";
        unsigned int n;
        cin >> n;
        for (int i=0; i < n; i++)
        {
            Fish* f = factory->create();
            pool.addFish(f);
        }
    }

    return pool;

}

Pool def()
{
    Pool pool(10,10);
    vector<Position> p = {{2,0},{4,4},{7,0}};
    Obstacle pen(p,"Penjing");
    pool.setObstacle(pen);
    vector<Position> sw = {{3,5},{6,8},{6,5}};
    Obstacle seaWeed(sw,"SeaWeed");
    pool.setObstacle(seaWeed);
    loadFactories(factories, pool.getLegalPos());
    for (FishFactory* factory : factories) {
        Fish* f = factory->create();
        pool.addFish(f);
    }
    return pool;
}

int main()
{

    Pool pool;
    cout << "Using default setup ? :" << endl;
    cout << "0.Yes  1.No" << endl;
    int mode;
    cin >> mode;
    if(mode) 
        pool = setUp();
    else
        pool =def();
    int step = 0;
    while(pool.getFishes().size() >1)
    {
        step ++;
        pool.show();
        pool.makeMove();
        pool.fight();
        Sleep (500);
    }
    cout << "Game over after " << step<< " steps" << endl;
    pool.show();
    for (FishFactory* factory : factories) {
        delete factory;
    }
    for (auto fish : pool.getFishes())
        delete fish;
      
    return 0;
}

